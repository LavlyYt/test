# mineping
ddos minecraft server

Требования
1. Хороший интернет
2. Хороший процессор
Как запустить?
java -jar mineping.jar host-айпи port-порт threads-500
